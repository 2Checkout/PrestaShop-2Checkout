<?php

/**
 * Interface jsonable
 */
interface Jsonable2CO {

	/**
	 * Get the instance as json.
	 *
	 * @return string
	 */
	public function toJson();

}
